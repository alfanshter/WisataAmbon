package com.sarah.wisata.Utils;

public class Constant {
    public String api = "http://192.168.1.14:8000/api/";
    public String storage = "http://192.168.1.14:8000/storage/";
}
